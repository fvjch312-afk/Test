# Test for bridge.py's idempotent tool calls and shared Studio check
# (run: python test-bridge.py). Works without the `websockets` package. Not shipped.
import asyncio, json, sys, time, types, threading

if "websockets" not in sys.modules:
    try:
        import websockets  # noqa: F401
    except ImportError:
        stub = types.ModuleType("websockets")
        stub.ConnectionClosed = type("ConnectionClosed", (Exception,), {})
        sys.modules["websockets"] = stub
import websockets
import bridge


class FakeWS:
    def __init__(self):
        self.sent, self.dead = [], False

    async def send(self, raw):
        if self.dead:
            raise websockets.ConnectionClosed()
        self.sent.append(json.loads(raw))


runs = []


def fake_safe_call(name, args, timeout):
    runs.append(name)
    time.sleep(0.3)
    return {"ok": True, "text": f"done {name} #{len(runs)}", "images": []}


bridge.safe_call = fake_safe_call


async def idempotency():
    old = FakeWS()
    t = asyncio.create_task(bridge.run_tool_task(old, "execute_luau", {}, 5, 1, "k1"))
    await asyncio.sleep(0.05)
    old.dead = True                      # socket dies while the tool runs
    await t
    new = FakeWS()
    await bridge.run_fetch_task(new, 7, "k1")
    assert new.sent[0]["ok"] and new.sent[0]["text"].endswith("#1") and len(runs) == 1
    again = FakeWS()
    await bridge.run_tool_task(again, "execute_luau", {}, 5, 8, "k1")   # re-sent request
    assert again.sent[0]["text"].endswith("#1") and len(runs) == 1
    unknown = FakeWS()
    await bridge.run_fetch_task(unknown, 9, "never-seen")
    assert unknown.sent[0]["kind"] == "unknown_request" and len(runs) == 1
    plain = FakeWS()
    await bridge.run_tool_task(plain, "list_commands", {}, 5, 3)         # no rkey: unchanged
    assert plain.sent[0]["ok"] and len(runs) == 2
    print("PASS idempotent tool calls")


def studio_check_is_shared():
    calls = []

    class R:
        stdout = "RobloxStudioBeta.exe  1234"

    def fake_run(cmd, **kw):
        calls.append(cmd)
        time.sleep(0.2)
        return R()

    real = (bridge.sys.platform, bridge.subprocess.run)
    bridge.sys.platform, bridge.subprocess.run = "win32", fake_run
    bridge._studio_proc_cache["t"] = None
    try:
        out = []
        ths = [threading.Thread(target=lambda: out.append(bridge._roblox_studio_app_running())) for _ in range(10)]
        [t.start() for t in ths]
        [t.join() for t in ths]
        assert set(out) == {True} and len(calls) == 1
    finally:
        bridge.sys.platform, bridge.subprocess.run = real
    print("PASS Studio process check shared across concurrent callers")


asyncio.run(idempotency())
studio_check_is_shared()
print("ALL BRIDGE TESTS PASSED")
