// Node test for background.js result recovery (run: node test-background.js). Not shipped.
const vm = require("vm"), fs = require("fs"), assert = require("assert");
function harness() {
  const sockets = []; let listener = null;
  class WS { constructor(url) { this.url = url; this.readyState = 0; this.sent = []; sockets.push(this); }
    send(d) { this.sent.push(JSON.parse(d)); } close() { if (this.readyState !== 3) { this.readyState = 3; this.onclose && this.onclose(); } } }
  WS.OPEN = 1; WS.CONNECTING = 0; WS.CLOSED = 3;
  const ctx = { WebSocket: WS, console: { log() {} }, setTimeout, clearTimeout, setInterval, clearInterval, Date, Math, JSON, Promise,
    chrome: { runtime: { onMessage: { addListener: (f) => (listener = f) }, onStartup: { addListener() {} }, onInstalled: { addListener() {} },
      sendMessage: () => Promise.resolve() }, tabs: { query: (q, cb) => cb([]), sendMessage: () => Promise.resolve() } } };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(__dirname + "/background.js", "utf8"), ctx);
  const open = (ws) => { ws.readyState = 1; ws.onopen && ws.onopen(); };
  const call = (msg) => new Promise((resolve) => listener(msg, null, resolve));
  return { sockets, open, call, ctx };
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  // ---- scenario 1: drop mid-call, bridge still has the result ----
  { const h = harness(); h.open(h.sockets[0]);
    const p = h.call({ type: "call_tool", name: "execute_luau", arguments: { code: "x" }, timeout: 20000 });
    await sleep(50);
    const first = h.sockets[0].sent.find((m) => m.type === "call_tool");
    assert(first && first.rkey, "call_tool carries an rkey");
    h.sockets[0].close();                                       // socket dies while the tool runs
    await sleep(100);
    const ws1 = h.sockets[h.sockets.length - 1]; assert.notStrictEqual(ws1, h.sockets[0], "reconnect attempted");
    h.open(ws1); await sleep(100);
    const fetch = ws1.sent.find((m) => m.type === "fetch_result");
    assert(fetch && fetch.rkey === first.rkey, "asks for the SAME request's result");
    assert(!ws1.sent.some((m) => m.type === "call_tool"), "never re-sends (re-executes) the command");
    ws1.onmessage({ data: JSON.stringify({ type: "tool_result", id: fetch.id, ok: true, text: "RESULT", images: [] }) });
    const r = await p; assert.strictEqual(r.ok, true); assert.strictEqual(r.text, "RESULT");
    console.log("PASS result recovered after socket drop; no re-execution"); }
  // ---- scenario 2: bridge restarted -> unknown_request -> old behaviour (disconnected) ----
  { const h = harness(); h.open(h.sockets[0]);
    const p = h.call({ type: "call_tool", name: "multi_edit", arguments: {}, timeout: 20000 });
    await sleep(50); h.sockets[0].close(); await sleep(100);
    const ws1 = h.sockets[h.sockets.length - 1]; h.open(ws1); await sleep(100);
    const fetch = ws1.sent.find((m) => m.type === "fetch_result");
    ws1.onmessage({ data: JSON.stringify({ type: "tool_result", id: fetch.id, ok: false, kind: "unknown_request", error: "x" }) });
    const r = await p; assert.strictEqual(r.ok, false); assert.strictEqual(r.kind, "disconnected");
    console.log("PASS unknown request falls back to 'disconnected' (never guesses)"); }
  // ---- scenario 3: normal call unaffected ----
  { const h = harness(); h.open(h.sockets[0]);
    const p = h.call({ type: "call_tool", name: "list_commands", arguments: {}, timeout: 20000 });
    await sleep(50); const m = h.sockets[0].sent.find((x) => x.type === "call_tool");
    h.sockets[0].onmessage({ data: JSON.stringify({ type: "tool_result", id: m.id, ok: true, text: "fine", images: [] }) });
    const r = await p; assert.strictEqual(r.text, "fine");
    assert(!h.sockets[0].sent.some((x) => x.type === "fetch_result"));
    console.log("PASS normal call path unchanged"); }
  // ---- scenario 4: bridge never comes back -> reports disconnected, doesn't hang ----
  { const h = harness(); h.open(h.sockets[0]);
    const p = h.call({ type: "call_tool", name: "x", arguments: {}, timeout: 4000 });   // 14s budget total
    await sleep(50); h.sockets[0].close();
    const t0 = Date.now(); const r = await Promise.race([p, sleep(16000).then(() => "HUNG")]);
    assert.notStrictEqual(r, "HUNG", "must not hang"); assert.strictEqual(r.kind, "disconnected");
    console.log("PASS bridge gone for good -> 'disconnected' after", ((Date.now() - t0) / 1000).toFixed(1) + "s"); }
  console.log("ALL BACKGROUND TESTS PASSED"); process.exit(0);
})().catch((e) => { console.error("FAIL", e); process.exit(1); });
