// SPDX-License-Identifier: GPL-3.0-or-later
const KOFI_URL = "https://ko-fi.com/sebattfg";
const SUPPORTED_HOSTS = [
  "chat.deepseek.com", "deepseek.com", "chatgpt.com", "chat.openai.com",
  "gemini.google.com", "www.kimi.ai", "kimi.ai",
  "chat.z.ai", "chat.qwen.ai", "arena.ai", "www.meta.ai", "meta.ai",
];
const DEFAULT_AI_URL = "https://chat.deepseek.com/";

// Exact-host check. The old `url.includes(host)` matched any URL that merely
// CONTAINED a host string (e.g. https://example.com/?q=meta.ai, or a lookalike
// such as openarena.ai), so "Settings" could message/activate the wrong tab.
function isSupportedUrl(url) {
  try {
    const h = new URL(url).hostname;
    return SUPPORTED_HOSTS.includes(h);
  } catch { return false; }
}

document.getElementById("ver").textContent = `v${chrome.runtime.getManifest().version}`;

function render(s) {
  const dot = document.getElementById("dot");
  const state = document.getElementById("state");
  const tools = document.getElementById("tools");
  const servers = document.getElementById("servers");
  const list = s.servers || [];
  const up = list.filter((x) => x.alive).length;
  const mcpOk = s.connected && (s.mcpAlive || up > 0 || s.tools > 0);
  const studioOff = mcpOk && s.studio === false; // MCP up but no Studio attached
  const ok = mcpOk && !studioOff;
  dot.className = "dot " + (s.connected ? (ok ? "on" : "warn") : "");
  state.textContent = s.connected
    ? (ok ? "Connected · Roblox Studio ready"
        : studioOff ? "Studio not connected · enable the MCP server in Studio"
        : "Bridge OK · open Roblox Studio")
    : "Bridge offline";
  tools.textContent = s.connected ? `${s.tools || 0} tools available` : "Start the bridge (see below)";
  servers.textContent = s.connected
    ? list.map((x) => `${x.alive ? "●" : "○"} ${x.id} (${x.alive ? x.tools + " tools" : "down"})`).join("\n")
    : "";
}

function refresh() {
  chrome.runtime.sendMessage({ type: "status" }, (s) => {
    void chrome.runtime.lastError; // worker asleep / restarting: just try again next tick
    if (s) render(s);
  });
}

// Run a background action with visible feedback. The button is disabled while the
// request is in flight (no double-fire) and ALWAYS restored - including when the
// service worker never answers, which used to leave "Restarting…" stuck forever.
function runAction(btn, busyLabel, msg) {
  const idle = btn.textContent;
  btn.disabled = true;
  btn.textContent = busyLabel;
  let done = false;
  const finish = () => {
    if (done) return;
    done = true;
    btn.disabled = false;
    btn.textContent = idle;
    setTimeout(refresh, 600);
  };
  const guard = setTimeout(finish, 15000);
  try {
    chrome.runtime.sendMessage(msg, () => { void chrome.runtime.lastError; clearTimeout(guard); finish(); });
  } catch { clearTimeout(guard); finish(); }
}
document.getElementById("reconnect").addEventListener("click", (e) =>
  runAction(e.currentTarget, "Reconnecting…", { type: "reconnect" }));
document.getElementById("restart").addEventListener("click", (e) =>
  runAction(e.currentTarget, "Restarting…", { type: "restart_mcp" }));
document.getElementById("kofi").addEventListener("click", () => {
  chrome.tabs.create({ url: KOFI_URL });
});
document.getElementById("settings").addEventListener("click", () => {
  // Same mechanism as the Ko-fi button (chrome.tabs), but tries the in-page
  // panel on an already-open supported AI tab first, so opening it doesn't
  // require a conversation to already be started there.
  chrome.tabs.query({}, (tabs) => {
    const active = tabs.find((t) => t.active && t.url && isSupportedUrl(t.url));
    const anySupported = active || tabs.find((t) => t.url && isSupportedUrl(t.url));
    if (anySupported) {
      chrome.tabs.sendMessage(anySupported.id, { type: "zs-open-menu" });
      chrome.tabs.update(anySupported.id, { active: true });
    } else {
      chrome.tabs.create({ url: DEFAULT_AI_URL });
    }
  });
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "zs-status") render(msg);
});
refresh();
// Push updates (zs-status) arrive on their own; this poll is only a fallback.
setInterval(() => { if (!document.hidden) refresh(); }, 3000);
